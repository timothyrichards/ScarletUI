function ScarletUI:SetupActionbars()
    if MainMenuBarArtFrameBackground then
        MainMenuBarArtFrameBackground:Hide()
    end

    if MainMenuBarArtFrame.LeftEndCap and MainMenuBarArtFrame.RightEndCap then
        MainMenuBarArtFrame.LeftEndCap:Hide()
        MainMenuBarArtFrame.RightEndCap:Hide()
    end

    local childrenMultiBarRight = { MultiBarRight:GetChildren() }
    local previousChildMultiBarRight;
    for __, child in ipairs(childrenMultiBarRight) do
        child:ClearAllPoints()

        if previousChildMultiBarRight then
            child:SetPoint("LEFT", previousChildMultiBarRight, "RIGHT", 6, 0)
        else
            child:SetPoint("LEFT", MultiBarRight, "LEFT", 0, 0)
        end

        previousChildMultiBarRight = child
    end

    local childrenMultiBarLeft = { MultiBarLeft:GetChildren() }
    local previousChildMultiBarLeft;
    for __, child in ipairs(childrenMultiBarLeft) do
        child:ClearAllPoints()

        if previousChildMultiBarLeft then
            child:SetPoint("LEFT", previousChildMultiBarLeft, "RIGHT", 6, 0)
        else
            child:SetPoint("LEFT", MultiBarLeft, "LEFT", 0, 0)
        end

        previousChildMultiBarLeft = child
    end

    --MultiBarBottomLeft:SetMovable(true)
    --MultiBarBottomLeft:SetUserPlaced(true)
    --MultiBarBottomLeft:ClearAllPoints()
    --MultiBarBottomLeft:SetWidth(500)
    --MultiBarBottomLeft:SetHeight(40)
    --MultiBarBottomLeft:SetPoint("BOTTOMLEFT", ActionButton1, "TOPLEFT", 0, 6)
    --MultiBarBottomLeft.SetPoint = function() end

    MultiBarRight:SetMovable(true)
    MultiBarRight:SetUserPlaced(true)
    MultiBarRight:ClearAllPoints()
    MultiBarRight:SetWidth(500)
    MultiBarRight:SetHeight(40)
    MultiBarRight:SetPoint("BOTTOMLEFT", MultiBarBottomLeft, "TOPLEFT", 0, 2)
    --MultiBarRight.SetPoint = function() end

    MultiBarLeft:SetMovable(true)
    MultiBarLeft:SetUserPlaced(true)
    MultiBarLeft:ClearAllPoints()
    MultiBarLeft:SetWidth(500)
    MultiBarLeft:SetHeight(40)
    MultiBarLeft:SetPoint("BOTTOMLEFT", MultiBarRight, "TOPLEFT", 0, 4)
    MultiBarLeft.SetPoint = function() end

    StanceBarFrame:SetMovable(true)
    StanceBarFrame:SetUserPlaced(true)
    StanceBarFrame:ClearAllPoints()
    StanceBarFrame:SetPoint("BOTTOMLEFT", MultiBarRight, "TOPLEFT", -4, 3)
    StanceBarFrame.SetPoint = function() end

    PetActionBarFrame:SetMovable(true)
    PetActionBarFrame:SetUserPlaced(true)
    PetActionBarFrame:ClearAllPoints()
    PetActionBarFrame:SetPoint("BOTTOMLEFT", StanceBarFrame, "TOPLEFT", -4, 3)
    PetActionBarFrame.SetPoint = function() end

    ScarletUI:TidyIcons_Update()
end